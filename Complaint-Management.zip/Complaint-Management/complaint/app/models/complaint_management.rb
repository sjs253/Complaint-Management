class ComplaintManagement < ApplicationRecord
end
