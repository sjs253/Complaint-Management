class ComplaintManagementsController < ApplicationController
  before_action :set_complaint_management, only: [:show, :edit, :update, :destroy]

  # GET /complaint_managements
  # GET /complaint_managements.json
  def index
    @complaint_managements = ComplaintManagement.all
  end

  # GET /complaint_managements/1
  # GET /complaint_managements/1.json
  def show
  end

  # GET /complaint_managements/new
  def new
    @complaint_management = ComplaintManagement.new
  end

  # GET /complaint_managements/1/edit
  def edit
  end

  # POST /complaint_managements
  # POST /complaint_managements.json
  def create
    @complaint_management = ComplaintManagement.new(complaint_management_params)

    respond_to do |format|
      if @complaint_management.save
        format.html { redirect_to @complaint_management, notice: 'Complaint management was successfully created.' }
        format.json { render :show, status: :created, location: @complaint_management }
      else
        format.html { render :new }
        format.json { render json: @complaint_management.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /complaint_managements/1
  # PATCH/PUT /complaint_managements/1.json
  def update
    respond_to do |format|
      if @complaint_management.update(complaint_management_params)
        format.html { redirect_to @complaint_management, notice: 'Complaint management was successfully updated.' }
        format.json { render :show, status: :ok, location: @complaint_management }
      else
        format.html { render :edit }
        format.json { render json: @complaint_management.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /complaint_managements/1
  # DELETE /complaint_managements/1.json
  def destroy
    @complaint_management.destroy
    respond_to do |format|
      format.html { redirect_to complaint_managements_url, notice: 'Complaint management was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_complaint_management
      @complaint_management = ComplaintManagement.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def complaint_management_params
      params.require(:complaint_management).permit(:title, :description)
    end
end
