class AddColumnComplaintStatusToComplaintManagement < ActiveRecord::Migration[5.2]
  def change
    add_column :complaint_managements, :complaint_status, :text
  end
end
