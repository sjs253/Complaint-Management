require 'test_helper'

class ComplaintManagementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
