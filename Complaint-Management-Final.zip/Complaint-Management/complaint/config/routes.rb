Rails.application.routes.draw do
  devise_for :users
  resources :complaint_managements
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.htmL
  root "complaint_managements#index"
end
