class AddColumnUserIdToComplaintManagement < ActiveRecord::Migration[5.2]
  def change
    add_column :complaint_managements, :user_id, :integer
  end
end
