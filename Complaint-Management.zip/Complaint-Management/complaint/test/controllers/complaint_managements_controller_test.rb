require 'test_helper'

class ComplaintManagementsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @complaint_management = complaint_managements(:one)
  end

  test "should get index" do
    get complaint_managements_url
    assert_response :success
  end

  test "should get new" do
    get new_complaint_management_url
    assert_response :success
  end

  test "should create complaint_management" do
    assert_difference('ComplaintManagement.count') do
      post complaint_managements_url, params: { complaint_management: { description: @complaint_management.description, title: @complaint_management.title } }
    end

    assert_redirected_to complaint_management_url(ComplaintManagement.last)
  end

  test "should show complaint_management" do
    get complaint_management_url(@complaint_management)
    assert_response :success
  end

  test "should get edit" do
    get edit_complaint_management_url(@complaint_management)
    assert_response :success
  end

  test "should update complaint_management" do
    patch complaint_management_url(@complaint_management), params: { complaint_management: { description: @complaint_management.description, title: @complaint_management.title } }
    assert_redirected_to complaint_management_url(@complaint_management)
  end

  test "should destroy complaint_management" do
    assert_difference('ComplaintManagement.count', -1) do
      delete complaint_management_url(@complaint_management)
    end

    assert_redirected_to complaint_managements_url
  end
end
