class AddColumnComplaintByToComplaintManagement < ActiveRecord::Migration[5.2]
  def change
    add_column :complaint_managements, :complaint_by, :text
  end
end
