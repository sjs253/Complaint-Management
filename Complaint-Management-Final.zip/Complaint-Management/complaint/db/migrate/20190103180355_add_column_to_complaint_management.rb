class AddColumnToComplaintManagement < ActiveRecord::Migration[5.2]
  def change
    add_column :complaint_managements, :is_admin, :boolean, default: false
  end
end
